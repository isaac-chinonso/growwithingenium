    $(document).ready(function() {

        $('.textarea_editor').wysihtml5({
            "stylesheets": false
        });


    });